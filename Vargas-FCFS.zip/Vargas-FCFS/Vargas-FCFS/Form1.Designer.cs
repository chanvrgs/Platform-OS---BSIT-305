﻿namespace Vargas_FCFS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblPBT1 = new System.Windows.Forms.Label();
            this.progressBar4 = new System.Windows.Forms.ProgressBar();
            this.progressBar3 = new System.Windows.Forms.ProgressBar();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.lblATT = new System.Windows.Forms.Label();
            this.lblAWT = new System.Windows.Forms.Label();
            this.lblToT = new System.Windows.Forms.Label();
            this.lblToWT = new System.Windows.Forms.Label();
            this.btnRUN = new System.Windows.Forms.Button();
            this.P1 = new System.Windows.Forms.Label();
            this.P2 = new System.Windows.Forms.Label();
            this.P3 = new System.Windows.Forms.Label();
            this.P4 = new System.Windows.Forms.Label();
            this.txtBT1 = new System.Windows.Forms.TextBox();
            this.txtBT2 = new System.Windows.Forms.TextBox();
            this.txtBT3 = new System.Windows.Forms.TextBox();
            this.txtBT4 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblWT4 = new System.Windows.Forms.Label();
            this.lblWT3 = new System.Windows.Forms.Label();
            this.lblWT2 = new System.Windows.Forms.Label();
            this.lblWT1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblT4 = new System.Windows.Forms.Label();
            this.lblT3 = new System.Windows.Forms.Label();
            this.lblT2 = new System.Windows.Forms.Label();
            this.lblT1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnReset = new System.Windows.Forms.Button();
            this.lblPBWT1 = new System.Windows.Forms.Label();
            this.lblPBT2 = new System.Windows.Forms.Label();
            this.lblPBT3 = new System.Windows.Forms.Label();
            this.lblPBT4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PaleTurquoise;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.lblPBT4);
            this.panel1.Controls.Add(this.lblPBT3);
            this.panel1.Controls.Add(this.lblPBT2);
            this.panel1.Controls.Add(this.lblPBWT1);
            this.panel1.Controls.Add(this.btnReset);
            this.panel1.Controls.Add(this.lblPBT1);
            this.panel1.Controls.Add(this.progressBar4);
            this.panel1.Controls.Add(this.progressBar3);
            this.panel1.Controls.Add(this.progressBar2);
            this.panel1.Controls.Add(this.progressBar1);
            this.panel1.Controls.Add(this.lblATT);
            this.panel1.Controls.Add(this.lblAWT);
            this.panel1.Controls.Add(this.lblToT);
            this.panel1.Controls.Add(this.lblToWT);
            this.panel1.Controls.Add(this.btnRUN);
            this.panel1.Location = new System.Drawing.Point(240, 13);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(432, 293);
            this.panel1.TabIndex = 0;
            // 
            // lblPBT1
            // 
            this.lblPBT1.AutoSize = true;
            this.lblPBT1.Location = new System.Drawing.Point(108, 133);
            this.lblPBT1.Name = "lblPBT1";
            this.lblPBT1.Size = new System.Drawing.Size(13, 13);
            this.lblPBT1.TabIndex = 25;
            this.lblPBT1.Text = "0";
            // 
            // progressBar4
            // 
            this.progressBar4.Location = new System.Drawing.Point(315, 149);
            this.progressBar4.Name = "progressBar4";
            this.progressBar4.Size = new System.Drawing.Size(100, 23);
            this.progressBar4.TabIndex = 32;
            // 
            // progressBar3
            // 
            this.progressBar3.Location = new System.Drawing.Point(215, 149);
            this.progressBar3.Name = "progressBar3";
            this.progressBar3.Size = new System.Drawing.Size(100, 23);
            this.progressBar3.TabIndex = 31;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(115, 149);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(100, 23);
            this.progressBar2.TabIndex = 30;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(15, 149);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(100, 23);
            this.progressBar1.TabIndex = 29;
            // 
            // lblATT
            // 
            this.lblATT.AutoSize = true;
            this.lblATT.Location = new System.Drawing.Point(106, 237);
            this.lblATT.Name = "lblATT";
            this.lblATT.Size = new System.Drawing.Size(37, 13);
            this.lblATT.TabIndex = 28;
            this.lblATT.Text = "ATT =";
            // 
            // lblAWT
            // 
            this.lblAWT.AutoSize = true;
            this.lblAWT.Location = new System.Drawing.Point(18, 237);
            this.lblAWT.Name = "lblAWT";
            this.lblAWT.Size = new System.Drawing.Size(41, 13);
            this.lblAWT.TabIndex = 27;
            this.lblAWT.Text = "AWT =";
            // 
            // lblToT
            // 
            this.lblToT.AutoSize = true;
            this.lblToT.Location = new System.Drawing.Point(106, 211);
            this.lblToT.Name = "lblToT";
            this.lblToT.Size = new System.Drawing.Size(36, 13);
            this.lblToT.TabIndex = 26;
            this.lblToT.Text = "ToT =";
            // 
            // lblToWT
            // 
            this.lblToWT.AutoSize = true;
            this.lblToWT.Location = new System.Drawing.Point(18, 211);
            this.lblToWT.Name = "lblToWT";
            this.lblToWT.Size = new System.Drawing.Size(47, 13);
            this.lblToWT.TabIndex = 25;
            this.lblToWT.Text = "ToWT =";
            // 
            // btnRUN
            // 
            this.btnRUN.Location = new System.Drawing.Point(3, 3);
            this.btnRUN.Name = "btnRUN";
            this.btnRUN.Size = new System.Drawing.Size(99, 42);
            this.btnRUN.TabIndex = 0;
            this.btnRUN.Text = "Run";
            this.btnRUN.UseVisualStyleBackColor = true;
            this.btnRUN.Click += new System.EventHandler(this.btnRUN_Click);
            // 
            // P1
            // 
            this.P1.AutoSize = true;
            this.P1.Location = new System.Drawing.Point(24, 46);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(20, 13);
            this.P1.TabIndex = 1;
            this.P1.Text = "P1";
            this.P1.Click += new System.EventHandler(this.P1_Click);
            // 
            // P2
            // 
            this.P2.AutoSize = true;
            this.P2.Location = new System.Drawing.Point(24, 72);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(20, 13);
            this.P2.TabIndex = 2;
            this.P2.Text = "P2";
            // 
            // P3
            // 
            this.P3.AutoSize = true;
            this.P3.Location = new System.Drawing.Point(24, 98);
            this.P3.Name = "P3";
            this.P3.Size = new System.Drawing.Size(20, 13);
            this.P3.TabIndex = 3;
            this.P3.Text = "P3";
            // 
            // P4
            // 
            this.P4.AutoSize = true;
            this.P4.Location = new System.Drawing.Point(24, 124);
            this.P4.Name = "P4";
            this.P4.Size = new System.Drawing.Size(20, 13);
            this.P4.TabIndex = 4;
            this.P4.Text = "P4";
            // 
            // txtBT1
            // 
            this.txtBT1.Location = new System.Drawing.Point(84, 43);
            this.txtBT1.Name = "txtBT1";
            this.txtBT1.Size = new System.Drawing.Size(46, 20);
            this.txtBT1.TabIndex = 5;
            this.txtBT1.Text = "1";
            this.txtBT1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBT1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtBT1_MouseClick);
            // 
            // txtBT2
            // 
            this.txtBT2.Location = new System.Drawing.Point(84, 69);
            this.txtBT2.Name = "txtBT2";
            this.txtBT2.Size = new System.Drawing.Size(46, 20);
            this.txtBT2.TabIndex = 6;
            this.txtBT2.Text = "1";
            this.txtBT2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBT2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtBT2_MouseClick);
            this.txtBT2.TextChanged += new System.EventHandler(this.txtBT2_TextChanged);
            // 
            // txtBT3
            // 
            this.txtBT3.Location = new System.Drawing.Point(84, 95);
            this.txtBT3.Name = "txtBT3";
            this.txtBT3.Size = new System.Drawing.Size(46, 20);
            this.txtBT3.TabIndex = 7;
            this.txtBT3.Text = "1";
            this.txtBT3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBT3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtBT3_MouseClick);
            // 
            // txtBT4
            // 
            this.txtBT4.Location = new System.Drawing.Point(84, 121);
            this.txtBT4.Name = "txtBT4";
            this.txtBT4.Size = new System.Drawing.Size(46, 20);
            this.txtBT4.TabIndex = 8;
            this.txtBT4.Text = "1";
            this.txtBT4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBT4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.txtBT4_MouseClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Burst Time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(157, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Arrival Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(183, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 13);
            this.label3.TabIndex = 14;
            this.label3.Text = "0";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(183, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(183, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(183, 46);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "0";
            // 
            // lblWT4
            // 
            this.lblWT4.AutoSize = true;
            this.lblWT4.Location = new System.Drawing.Point(39, 277);
            this.lblWT4.Name = "lblWT4";
            this.lblWT4.Size = new System.Drawing.Size(40, 13);
            this.lblWT4.TabIndex = 18;
            this.lblWT4.Text = "WT4 =";
            // 
            // lblWT3
            // 
            this.lblWT3.AutoSize = true;
            this.lblWT3.Location = new System.Drawing.Point(39, 251);
            this.lblWT3.Name = "lblWT3";
            this.lblWT3.Size = new System.Drawing.Size(40, 13);
            this.lblWT3.TabIndex = 17;
            this.lblWT3.Text = "WT3 =";
            // 
            // lblWT2
            // 
            this.lblWT2.AutoSize = true;
            this.lblWT2.Location = new System.Drawing.Point(39, 225);
            this.lblWT2.Name = "lblWT2";
            this.lblWT2.Size = new System.Drawing.Size(40, 13);
            this.lblWT2.TabIndex = 16;
            this.lblWT2.Text = "WT2 =";
            // 
            // lblWT1
            // 
            this.lblWT1.AutoSize = true;
            this.lblWT1.Location = new System.Drawing.Point(39, 199);
            this.lblWT1.Name = "lblWT1";
            this.lblWT1.Size = new System.Drawing.Size(40, 13);
            this.lblWT1.TabIndex = 15;
            this.lblWT1.Text = "WT1 =";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(24, 173);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Waiting Time";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(127, 173);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "Turnaround Time";
            // 
            // lblT4
            // 
            this.lblT4.AutoSize = true;
            this.lblT4.Location = new System.Drawing.Point(155, 277);
            this.lblT4.Name = "lblT4";
            this.lblT4.Size = new System.Drawing.Size(29, 13);
            this.lblT4.TabIndex = 23;
            this.lblT4.Text = "T4 =";
            // 
            // lblT3
            // 
            this.lblT3.AutoSize = true;
            this.lblT3.Location = new System.Drawing.Point(155, 251);
            this.lblT3.Name = "lblT3";
            this.lblT3.Size = new System.Drawing.Size(29, 13);
            this.lblT3.TabIndex = 22;
            this.lblT3.Text = "T3 =";
            // 
            // lblT2
            // 
            this.lblT2.AutoSize = true;
            this.lblT2.Location = new System.Drawing.Point(155, 225);
            this.lblT2.Name = "lblT2";
            this.lblT2.Size = new System.Drawing.Size(29, 13);
            this.lblT2.TabIndex = 21;
            this.lblT2.Text = "T2 =";
            // 
            // lblT1
            // 
            this.lblT1.AutoSize = true;
            this.lblT1.Location = new System.Drawing.Point(155, 199);
            this.lblT1.Name = "lblT1";
            this.lblT1.Size = new System.Drawing.Size(29, 13);
            this.lblT1.TabIndex = 20;
            this.lblT1.Text = "T1 =";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(109, 3);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(99, 42);
            this.btnReset.TabIndex = 33;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblPBWT1
            // 
            this.lblPBWT1.AutoSize = true;
            this.lblPBWT1.Location = new System.Drawing.Point(12, 133);
            this.lblPBWT1.Name = "lblPBWT1";
            this.lblPBWT1.Size = new System.Drawing.Size(13, 13);
            this.lblPBWT1.TabIndex = 34;
            this.lblPBWT1.Text = "0";
            // 
            // lblPBT2
            // 
            this.lblPBT2.AutoSize = true;
            this.lblPBT2.Location = new System.Drawing.Point(209, 133);
            this.lblPBT2.Name = "lblPBT2";
            this.lblPBT2.Size = new System.Drawing.Size(13, 13);
            this.lblPBT2.TabIndex = 36;
            this.lblPBT2.Text = "0";
            // 
            // lblPBT3
            // 
            this.lblPBT3.AutoSize = true;
            this.lblPBT3.Location = new System.Drawing.Point(309, 133);
            this.lblPBT3.Name = "lblPBT3";
            this.lblPBT3.Size = new System.Drawing.Size(13, 13);
            this.lblPBT3.TabIndex = 39;
            this.lblPBT3.Text = "0";
            // 
            // lblPBT4
            // 
            this.lblPBT4.AutoSize = true;
            this.lblPBT4.Location = new System.Drawing.Point(402, 133);
            this.lblPBT4.Name = "lblPBT4";
            this.lblPBT4.Size = new System.Drawing.Size(13, 13);
            this.lblPBT4.TabIndex = 40;
            this.lblPBT4.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(53, 88);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 13);
            this.label7.TabIndex = 25;
            this.label7.Text = "P1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(153, 88);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(20, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "P2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(253, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "P3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(351, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "P4";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumAquamarine;
            this.ClientSize = new System.Drawing.Size(684, 318);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lblT4);
            this.Controls.Add(this.lblT3);
            this.Controls.Add(this.lblT2);
            this.Controls.Add(this.lblT1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.lblWT4);
            this.Controls.Add(this.lblWT3);
            this.Controls.Add(this.lblWT2);
            this.Controls.Add(this.lblWT1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBT4);
            this.Controls.Add(this.txtBT3);
            this.Controls.Add(this.txtBT2);
            this.Controls.Add(this.txtBT1);
            this.Controls.Add(this.P4);
            this.Controls.Add(this.P3);
            this.Controls.Add(this.P2);
            this.Controls.Add(this.P1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "First Come First Serve";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label P1;
        private System.Windows.Forms.Label P2;
        private System.Windows.Forms.Label P3;
        private System.Windows.Forms.Label P4;
        private System.Windows.Forms.TextBox txtBT1;
        private System.Windows.Forms.TextBox txtBT2;
        private System.Windows.Forms.TextBox txtBT3;
        private System.Windows.Forms.TextBox txtBT4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblWT4;
        private System.Windows.Forms.Label lblWT3;
        private System.Windows.Forms.Label lblWT2;
        private System.Windows.Forms.Label lblWT1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnRUN;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblT4;
        private System.Windows.Forms.Label lblT3;
        private System.Windows.Forms.Label lblT2;
        private System.Windows.Forms.Label lblT1;
        private System.Windows.Forms.Label lblToT;
        private System.Windows.Forms.Label lblToWT;
        private System.Windows.Forms.Label lblATT;
        private System.Windows.Forms.Label lblAWT;
        private System.Windows.Forms.ProgressBar progressBar4;
        private System.Windows.Forms.ProgressBar progressBar3;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblPBT1;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblPBT4;
        private System.Windows.Forms.Label lblPBT3;
        private System.Windows.Forms.Label lblPBT2;
        private System.Windows.Forms.Label lblPBWT1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}

