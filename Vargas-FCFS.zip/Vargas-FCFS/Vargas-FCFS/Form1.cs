﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Vargas_FCFS
{
    public partial class Form1 : Form
    {
        private void Execute() {

            int p1 = Int32.Parse(txtBT1.Text);
            int p2 = Int32.Parse(txtBT2.Text);
            int p3 = Int32.Parse(txtBT3.Text);
            int p4 = Int32.Parse(txtBT4.Text);

            int trb = p1 + p2;
            int trc = trb + p3;
            int trd = trc + p4;

            int ToWT = 0 + p1 + trb + trc;
            int ToT = p1 + trb + trc + trd;

            double AWT = (double)ToWT / 4;
            double ATT = (double)ToT / 4;

            string tra = p1.ToString();
            string trbb = trb.ToString();
            string trcc = trc.ToString();
            string trdd = trd.ToString();

            lblWT1.Text = "WT1 = 0";
            lblT1.Text = "T1 = " + tra;

            lblWT2.Text = "WT2 = " + tra;
            lblT2.Text = "T2 = " + trbb;

            lblWT3.Text = "WT3 = " + trbb;
            lblT3.Text = "T3 = " + trcc;

            lblWT4.Text = "WT4 = " + trcc;
            lblT4.Text = "T4 = " + trdd;

            lblToWT.Text = "ToWT = " + ToWT;
            lblToT.Text = "ToT = " + ToT;

            lblAWT.Text = "AWT = " + ToWT + "/ 4" + "\n\n         = " + AWT;
            lblATT.Text = "ATT = " + ToT + "/ 4" + "\n\n        = " + ATT;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void P1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnRUN_Click(object sender, EventArgs e)
        {
            timer1.Start();
            
        }

        private void txtBT1_MouseClick(object sender, MouseEventArgs e)
        {
            txtBT1.Text = "";
        }

        private void txtBT2_MouseClick(object sender, MouseEventArgs e)
        {
            txtBT2.Text = "";
        }

        private void txtBT3_MouseClick(object sender, MouseEventArgs e)
        {
            txtBT3.Text = "";
        }

        private void txtBT4_MouseClick(object sender, MouseEventArgs e)
        {
            txtBT4.Text = "";
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Interval = int.Parse(txtBT1.Text);
            progressBar1.Increment(1);
            

            if (progressBar1.Value == 100)
            {
                lblPBT1.Text = txtBT1.Text;
                timer1.Interval = int.Parse(txtBT2.Text);
                progressBar2.Increment(1);

                if (progressBar2.Value == 100)
                {
                    int PBT2 = int.Parse(txtBT1.Text) + int.Parse(txtBT2.Text);
                    lblPBT2.Text = PBT2.ToString();
                    timer1.Interval = int.Parse(txtBT3.Text);
                    progressBar3.Increment(1);

                    if (progressBar3.Value == 100)
                    {
                        int PBWT4 = int.Parse(txtBT1.Text) + int.Parse(txtBT2.Text) + int.Parse(txtBT3.Text);
                        lblPBT3.Text = PBWT4.ToString();
                        timer1.Interval = int.Parse(txtBT4.Text);
                        progressBar4.Increment(1);

                        if (progressBar4.Value == 100)
                        {
                            int PBT4 = int.Parse(txtBT1.Text) + int.Parse(txtBT2.Text) + int.Parse(txtBT3.Text) + int.Parse(txtBT4.Text);
                            lblPBT4.Text = PBT4.ToString();
                            Execute();
                        }
                    }
                }
            }
        }

        private void txtBT2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            timer1.Stop();

            progressBar1.Value = 0;
            progressBar2.Value = 0;
            progressBar3.Value = 0;
            progressBar4.Value = 0;

            lblPBT1.Text = "0";
            lblPBT2.Text = "0";
            lblPBT3.Text = "0";
            lblPBT4.Text = "0";

            txtBT1.Text = "1";
            txtBT2.Text = "1";
            txtBT3.Text = "1";
            txtBT4.Text = "1";

            lblWT1.Text = "WT1 =";
            lblT1.Text = "T1 =";

            lblWT2.Text = "WT2 =";
            lblT2.Text = "T2 =";

            lblWT3.Text = "WT3 =";
            lblT3.Text = "T3 =";

            lblWT4.Text = "WT4 =";
            lblT4.Text = "T4 =";

            lblToWT.Text = "ToWT =";
            lblToT.Text = "ToT =";

            lblAWT.Text = "AWT =";
            lblATT.Text = "ATT =";
        }
    }
}
